class m{
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};
        int rotations = 2;
        
        rotateArray(arr, rotations);
        
        // Print the rotated array
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }
    
    public static void rotateArray(int[] arr, int rotations) {
        int n = arr.length;
        
        // Rotate the array 'rotations' number of times
        for (int i = 0; i < rotations; i++) {
            int lastElement = arr[n - 1];
            
            // Shift each element to the right
            for (int j = n - 1; j > 0; j--) {
                arr[j] = arr[j - 1];
            }
            
            // Place the last element at the beginning
            arr[0] = lastElement;
        }
    }
    }
